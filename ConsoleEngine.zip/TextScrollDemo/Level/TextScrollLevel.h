#pragma once

#include <Level/Level.h>

class TextScrollLevel : public Level
{
	RTTI_DECLARATIONS(TextScrollLevel, Level)

public:
	TextScrollLevel();
};